"use client"
import { useNavigate } from "react-router-dom"
import { useDispatch } from "react-redux"
import { logout } from "../features/auth/authSlice"
import { LockKeyhole } from "lucide-react"
import '../pages/unauthorized.css'
const Unauthorized = () => {
    const navigate = useNavigate()
    const dispatch = useDispatch()

    const handleLogout = () => {
        dispatch(logout())
        navigate("/user-login")
    }

    return (
        <div className="unauthorized-page">
            <div className="unauthorized-card">
                <div className="card-header">
                    <LockKeyhole className="lock-icon" />
                    <h1>Access Denied</h1>
                </div>

                <div className="card-body">
                    <p>You don't have permission to access this resource.</p>

                    <div className="action-buttons">
                        <button className="secondary-btn" onClick={() => navigate(-1)}>
                            Go Back
                        </button>
                        <button className="primary-btn" onClick={handleLogout}>
                            Logout & Return Home
                        </button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Unauthorized