export const API_BASE_URL = 'https://webstrategy.co.in/rssdi/api';
export const IMAGE_BASE_URL = 'https://webstrategy.co.in/rssdi';
export const API_TIMEOUT = 30000; // 30 seconds