    export const API_BASE_URL = 'https://rssdi.dfri.in/rssdi/api';
    export const IMAGE_BASE_URL = 'https://rssdi.dfri.in/rssdi/';
    export const API_TIMEOUT = 30000; // 30 seconds
