"use client"

import { useState, useRef, useEffect } from "react"
import { Link } from "react-router-dom"
import { FaUserCircle, FaUserCog, FaLock, FaSignOutAlt, FaChevronDown } from "react-icons/fa"
import { useSelector, useDispatch } from "react-redux"
import { setCredentials } from "../features/auth/authSlice"
import { apiRequest } from "../services/api-helper"
import "./Header.css"
import { IMAGE_BASE_URL } from "../config/api"

const Header = () => {
    const [isDropdownOpen, setIsDropdownOpen] = useState(false)
    const dropdownRef = useRef(null)
    const dispatch = useDispatch()
    const user = useSelector((state) => state.auth.user)
    const [avatarLoaded, setAvatarLoaded] = useState(false)
    const [lastFetchTime, setLastFetchTime] = useState(0)

    console.log("Current user in header:", user)

    const toggleDropdown = () => {
        setIsDropdownOpen(!isDropdownOpen)
    }

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsDropdownOpen(false)
            }
        }
        document.addEventListener("mousedown", handleClickOutside)
        return () => {
            document.removeEventListener("mousedown", handleClickOutside)
        }
    }, [])

    useEffect(() => {
        const fetchProfile = async () => {
            const now = Date.now()
            if (now - lastFetchTime < 60000 && lastFetchTime !== 0) {
                console.log("Skipping profile fetch - too soon since last fetch")
                return
            }

            try {
                console.log("Fetching profile...")
                setLastFetchTime(now)

                const response = await apiRequest(
                    "/admin/profile",
                    {
                        method: "GET",
                        headers: {
                            Accept: "application/json",
                            Authorization: `Bearer ${user.token}`,
                        },
                    },
                    2,
                    user.token,
                )

                console.log("Profile API response in Header:", response)

                if (response) {
                    const profileData = response.data || response
                    console.log("Profile data in Header:", profileData)

                    const avatarUrl = profileData.avatar
                        ? `${IMAGE_BASE_URL}${profileData.avatar.startsWith('/') ? '' : '/'}${profileData.avatar}?t=${Date.now()}`
                        : user.avatar && !user.avatar.includes("undefined") ? user.avatar : "";

                    if (avatarUrl && !avatarUrl.includes("undefined")) {
                        console.log("Avatar URL found:", avatarUrl)
                        const img = new Image()
                        img.src = avatarUrl
                        img.onload = () => {
                            console.log("Image loaded successfully")
                            setAvatarLoaded(true)
                            dispatch(setCredentials({
                                user: {
                                    ...user,
                                    ...profileData,
                                    avatar: avatarUrl,
                                    picture: avatarUrl,
                                    admin_id: profileData.admin_id || user.admin_id,
                                    username: profileData.username || user.username,
                                },
                                token: user.token,
                                role: "admin",
                            }));
                        }
                        img.onerror = (e) => {
                            console.error("Failed to load avatar image:", e)
                            setAvatarLoaded(false)
                            dispatch(setCredentials({
                                user: {
                                    ...user,
                                    ...profileData,
                                    avatar: "",
                                    picture: "",
                                    admin_id: profileData.admin_id || user.admin_id,
                                    username: profileData.username || user.username,
                                },
                                token: user.token,
                                role: "admin",
                            }));
                        }
                    } else {
                        console.log("No valid avatar URL found in profile data")
                        dispatch(setCredentials({
                            user: {
                                ...user,
                                ...profileData,
                                avatar: "",
                                picture: "",
                                admin_id: profileData.admin_id || user.admin_id,
                                username: profileData.username || user.username,
                            },
                            token: user.token,
                            role: "admin",
                        }))
                    }
                }
            } catch (error) {
                console.error("Header: Failed to fetch profile:", error)
            }
        }

        if (user?.token) {
            const needsFetch = !user.picture || user.picture.includes("undefined") || !avatarLoaded
            console.log("Needs profile fetch?", needsFetch, "Avatar loaded?", avatarLoaded)

            if (needsFetch) {
                fetchProfile()
            }
        }
    }, [user?.token, user?.picture, avatarLoaded, lastFetchTime, dispatch])

    useEffect(() => {
        if (user?.picture || user?.avatar) {
            console.log("Attempting to display image:", user.picture || user.avatar)
        }
    }, [user?.picture, user?.avatar])

    return (
        <header className="admin-header">
            <div className="header-content">
                <div className="header-title">{/* Optional header title/logo */}</div>
                <div className="header-actions">
                    <div className="profile-dropdown" ref={dropdownRef}>
                        <button
                            className={`profile-button ${isDropdownOpen ? "active" : ""}`}
                            onClick={toggleDropdown}
                            aria-expanded={isDropdownOpen}
                            aria-label="User profile menu"
                        >
                            <div className="profile-info">
                                {(user?.picture || user?.avatar) && avatarLoaded && !user?.picture?.includes("undefined") ? (
                                    <img
                                        src={user.picture || user.avatar}
                                        alt="Profile"
                                        className="profile-picture"
                                        onError={(e) => {
                                            console.error("Image load error in render:", e.target.src)
                                            e.target.style.display = "none"
                                            setAvatarLoaded(false)
                                        }}
                                    />
                                ) : (
                                    <FaUserCircle className="profile-icon" />
                                )}
                                <span className="profile-name">{ user?.email || "Admin"}</span>
                                <FaChevronDown className={`dropdown-arrow ${isDropdownOpen ? "rotate" : ""}`} />
                            </div>
                        </button>
                        <div className={`dropdown-menu ${isDropdownOpen ? "show" : ""}`}>
                            <span className="dropdown-item">{user?.name || "Admin"}</span>
                            <Link to="/admin/profile" className="dropdown-item">
                                <FaUserCog className="dropdown-icon" />
                                <span>My Profile</span>
                            </Link>
                            <Link to="/admin/change-password" className="dropdown-item">
                                <FaLock className="dropdown-icon" />
                                <span>Change Password</span>
                            </Link>
                            <div className="dropdown-divider"></div>
                            <Link to="/admin" className="dropdown-item logout">
                                <FaSignOutAlt className="dropdown-icon" />
                                <span>Logout</span>
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </header>
    )
}

export default Header